#include <stdio.h> 

void main()
{
	int a = (60*3-80)/25;
	float b = (float) (993+78)*65/654-598;
	printf("%d\n%.1f",a,b);
}
